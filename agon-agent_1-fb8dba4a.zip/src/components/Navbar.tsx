import { useState, useEffect } from 'react';
import { Menu, X, Phone, Clock } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-md shadow-lg py-2'
          : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${scrolled ? 'bg-primary' : 'bg-white/20'}`}>
              <svg width="24" height="24" viewBox="0 0 100 100" fill="none">
                <path d="M50 20c-8 0-14 6-16 14-2 8 2 18 8 26 2 3 4 8 4 14 0 4 2 6 4 6s4-2 4-6c0-6 2-11 4-14 6-8 10-18 8-26-2-8-8-14-16-14z" fill={scrolled ? 'white' : 'white'}/>
              </svg>
            </div>
            <div className="hidden sm:block">
              <h1 className={`font-display font-bold text-lg leading-tight ${scrolled ? 'text-dark' : 'text-white'}`}>
                Advance Dental
              </h1>
              <p className={`text-xs ${scrolled ? 'text-gray-500' : 'text-white/80'}`}>
                Dr. Zubair Banglani
              </p>
            </div>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  scrolled ? 'text-gray-700' : 'text-white/90'
                }`}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-4">
            <div className={`flex items-center gap-2 text-sm ${scrolled ? 'text-gray-600' : 'text-white/80'}`}>
              <Clock size={16} />
              <span>Open · Closes 10 PM</span>
            </div>
            <a
              href="tel:+923093013612"
              className="btn-primary text-white px-5 py-2.5 rounded-full text-sm font-medium flex items-center gap-2"
            >
              <Phone size={16} />
              Call Now
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`md:hidden p-2 rounded-lg ${scrolled ? 'text-gray-700' : 'text-white'}`}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t shadow-xl">
          <div className="px-4 py-4 space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block text-gray-700 font-medium py-2 hover:text-primary transition-colors"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-3 border-t">
              <a
                href="tel:+923093013612"
                className="btn-primary text-white px-5 py-3 rounded-full text-sm font-medium flex items-center justify-center gap-2 w-full"
              >
                <Phone size={16} />
                +92 309 3013612
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}

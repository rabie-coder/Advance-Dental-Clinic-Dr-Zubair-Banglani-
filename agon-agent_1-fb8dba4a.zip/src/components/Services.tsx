import { motion } from 'framer-motion';
import {
  Syringe,
  Sparkles,
  Smile,
  Stethoscope,
  ShieldCheck,
  Wrench,
  HeartPulse,
  Scan,
} from 'lucide-react';

const services = [
  {
    icon: Syringe,
    title: 'Teeth Filling',
    desc: 'High-quality dental fillings to restore damaged teeth and prevent further decay.',
  },
  {
    icon: Sparkles,
    title: 'Teeth Cleaning',
    desc: 'Professional cleaning to remove plaque, tartar, and stains for a brighter smile.',
  },
  {
    icon: Smile,
    title: 'Cosmetic Dentistry',
    desc: 'Enhance your smile with our cosmetic dental procedures and treatments.',
  },
  {
    icon: Stethoscope,
    title: 'Dental Checkup',
    desc: 'Comprehensive dental examinations with detailed explanations of your oral health.',
  },
  {
    icon: ShieldCheck,
    title: 'Root Canal',
    desc: 'Expert root canal treatment to save infected teeth and relieve pain.',
  },
  {
    icon: Wrench,
    title: 'Tooth Extraction',
    desc: 'Safe and painless tooth extraction when necessary, with proper aftercare.',
  },
  {
    icon: HeartPulse,
    title: 'Gum Treatment',
    desc: 'Specialized care for gum diseases and periodontal issues.',
  },
  {
    icon: Scan,
    title: 'Dental X-Rays',
    desc: 'Modern digital X-ray technology for accurate diagnosis and treatment planning.',
  },
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="section-divider mx-auto mb-6" />
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-dark mb-4">
            Our Dental Services
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            We offer a comprehensive range of dental services using modern equipment 
            and the latest techniques to ensure the best care for your teeth.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="service-card bg-white rounded-2xl p-6 border border-gray-100"
            >
              <div className="w-14 h-14 rounded-xl bg-primary-50 flex items-center justify-center mb-5">
                <service.icon size={28} className="text-primary" />
              </div>
              <h3 className="font-semibold text-dark text-lg mb-2">{service.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{service.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

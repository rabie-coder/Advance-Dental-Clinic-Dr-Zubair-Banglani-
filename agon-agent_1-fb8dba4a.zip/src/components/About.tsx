import { motion } from 'framer-motion';
import { Shield, Award, Heart, Users } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: Shield,
      title: 'Sterilization Protocols',
      desc: 'We follow strict sterilization protocols to ensure your safety and well-being.',
    },
    {
      icon: Award,
      title: 'Expert Dentist',
      desc: 'Dr. Zubair Banglani is a highly skilled dentist with years of experience.',
    },
    {
      icon: Heart,
      title: 'Patient Care',
      desc: 'We treat every patient with utmost care, empathy, and professionalism.',
    },
    {
      icon: Users,
      title: 'Friendly Staff',
      desc: 'Our team is incredibly friendly and makes you feel comfortable.',
    },
  ];

  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="/images/doctor.jpg"
                alt="Dr. Zubair Banglani"
                className="w-full h-[500px] object-cover object-top"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-dark/90 to-transparent p-8">
                <h3 className="font-display text-2xl font-bold text-white">Dr. Zubair Banglani</h3>
                <p className="text-white/80">Principal Dentist & Founder</p>
              </div>
            </div>
            {/* Floating badge */}
            <div className="absolute -top-4 -right-4 bg-primary text-white rounded-2xl p-4 shadow-xl animate-float">
              <div className="text-3xl font-bold">5+</div>
              <div className="text-sm text-white/80">Years Experience</div>
            </div>
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="section-divider mb-6" />
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-dark mb-6">
              About Our Clinic
            </h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              Advance Dental Clinic is one of the finest dental clinics in Sukkur, Pakistan. 
              Led by Dr. Zubair Banglani, we provide comprehensive dental care with modern 
              equipment and best facilities.
            </p>
            <p className="text-gray-600 leading-relaxed mb-10">
              Our clinic is equipped with all the latest dental equipment and follows proper 
              sterilization protocols. Dr. Zubair is known for his professionalism, polite 
              behavior, and ability to explain treatments clearly before starting any procedure.
            </p>

            {/* Feature Grid */}
            <div className="grid sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center flex-shrink-0">
                    <feature.icon size={24} className="text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-dark mb-1">{feature.title}</h4>
                    <p className="text-gray-500 text-sm">{feature.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

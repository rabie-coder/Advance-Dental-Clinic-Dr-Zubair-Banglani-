import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const reviews = [
  {
    name: 'Khiladi 90',
    rating: 5,
    time: '2 months ago',
    text: 'After searching for many clinics, I found this clinic. This is one of the finest dental clinic. They have all the equipments & best facilities with proper sterilization protocols. Dr Zubair Banglani is one of the best dentist to treat my dental issues.',
  },
  {
    name: 'Raza Official',
    rating: 5,
    time: '6 months ago',
    text: 'I had my teeth filling done by Dr. Zubair Banglani, and I\'m really satisfied with the service. He is very professional, polite, and explains everything clearly. The clinic was clean, and the staff were friendly. I\'m happy with the results highly recommended.',
  },
  {
    name: 'Fighter King',
    rating: 5,
    time: '2 months ago',
    text: 'Proper sterilization protocols is being followed, highly skilled Doctor who did treatment with utmost care & empathy. Highly recommend!',
  },
  {
    name: 'Shamas ul Din',
    rating: 5,
    time: '6 months ago',
    text: 'I was searching for a Near me Dentist because I had a sudden toothache, and I\'m so glad I found this amazing dental clinic! The staff was incredibly friendly, the environment was clean and relaxing, and the dentist explained every step clearly before starting the treatment. Thanks DR. Zubair Baloch.',
  },
  {
    name: 'Maindad Malik',
    rating: 5,
    time: '5 months ago',
    text: 'I can recommend Dr Zubair. I\'m very happy with the care and patience shown with my dental check-up, cleaning and filling. Thank you Dr Zubair and team.',
  },
];

export default function Reviews() {
  return (
    <section id="reviews" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="section-divider mx-auto mb-6" />
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-dark mb-4">
            What Our Patients Say
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Don't just take our word for it. Here's what our satisfied patients 
            have to say about their experience at Advance Dental Clinic.
          </p>

          {/* Overall Rating */}
          <div className="mt-8 inline-flex items-center gap-4 bg-primary-50 rounded-2xl px-8 py-4">
            <div className="text-4xl font-bold text-primary">5.0</div>
            <div className="text-left">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={18} className="text-yellow-400 fill-yellow-400" />
                ))}
              </div>
              <p className="text-gray-500 text-sm mt-1">Based on 30 reviews</p>
            </div>
          </div>
        </motion.div>

        {/* Reviews Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <motion.div
              key={review.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`review-card bg-gray-50 rounded-2xl p-6 relative ${
                index === 0 ? 'md:col-span-2 lg:col-span-1' : ''
              }`}
            >
              <Quote size={32} className="text-primary/20 mb-4" />
              <p className="text-gray-700 leading-relaxed mb-6">{review.text}</p>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-dark">{review.name}</h4>
                  <p className="text-gray-400 text-sm">{review.time}</p>
                </div>
                <div className="flex gap-0.5">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} size={14} className="text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { motion } from 'framer-motion';
import { Phone, MapPin, Star, ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-clinic.jpg"
          alt="Dental Clinic"
          className="w-full h-full object-cover"
        />
        <div className="hero-overlay absolute inset-0" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 mb-6">
              <Star size={16} className="text-yellow-400 fill-yellow-400" />
              <span className="text-white text-sm font-medium">5.0 Rating · 30+ Reviews</span>
            </div>

            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              Your Smile Deserves{' '}
              <span className="text-primary-light">Expert Care</span>
            </h1>

            <p className="text-white/80 text-lg mb-8 max-w-lg leading-relaxed">
              Advance Dental Clinic by Dr. Zubair Banglani offers professional dental care 
              with modern equipment, proper sterilization protocols, and a friendly environment 
              in Sukkur, Pakistan.
            </p>

            <div className="flex flex-wrap gap-4 mb-8">
              <a
                href="tel:+923093013612"
                className="btn-primary text-white px-8 py-4 rounded-full font-medium flex items-center gap-2 text-lg"
              >
                <Phone size={20} />
                Book Appointment
              </a>
              <a
                href="#services"
                className="bg-white/10 backdrop-blur-sm border border-white/30 text-white px-8 py-4 rounded-full font-medium hover:bg-white/20 transition-all"
              >
                Our Services
              </a>
            </div>

            {/* Quick Info */}
            <div className="flex flex-wrap gap-6">
              <div className="flex items-center gap-2 text-white/80">
                <MapPin size={18} className="text-primary-light" />
                <span className="text-sm">Sukkur, Pakistan</span>
              </div>
              <div className="flex items-center gap-2 text-white/80">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-sm">Open · Closes 10 PM</span>
              </div>
            </div>
          </motion.div>

          {/* Right side - Stats Cards */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="hidden lg:grid grid-cols-2 gap-4"
          >
            <div className="glass-card rounded-2xl p-6 text-center">
              <div className="text-4xl font-bold text-white mb-1">5.0</div>
              <div className="flex justify-center gap-1 mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className="text-yellow-400 fill-yellow-400" />
                ))}
              </div>
              <p className="text-white/70 text-sm">Star Rating</p>
            </div>
            <div className="glass-card rounded-2xl p-6 text-center">
              <div className="text-4xl font-bold text-white mb-1">30+</div>
              <p className="text-white/70 text-sm mt-3">Happy Patients</p>
            </div>
            <div className="glass-card rounded-2xl p-6 text-center">
              <div className="text-4xl font-bold text-white mb-1">10PM</div>
              <p className="text-white/70 text-sm mt-3">Open Until</p>
            </div>
            <div className="glass-card rounded-2xl p-6 text-center">
              <div className="text-4xl font-bold text-white mb-1">100%</div>
              <p className="text-white/70 text-sm mt-3">Sterilized</p>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.a
        href="#about"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/60 hover:text-white transition-colors"
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
      >
        <ChevronDown size={32} />
      </motion.a>
    </section>
  );
}

import { Phone, MapPin, Clock, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-dark text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 100 100" fill="none">
                  <path d="M50 20c-8 0-14 6-16 14-2 8 2 18 8 26 2 3 4 8 4 14 0 4 2 6 4 6s4-2 4-6c0-6 2-11 4-14 6-8 10-18 8-26-2-8-8-14-16-14z" fill="white"/>
                </svg>
              </div>
              <div>
                <h3 className="font-display font-bold text-lg">Advance Dental</h3>
                <p className="text-white/60 text-xs">Dr. Zubair Banglani</p>
              </div>
            </div>
            <p className="text-white/60 leading-relaxed">
              Providing quality dental care with modern equipment and sterilization 
              protocols in Sukkur, Pakistan.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'About', 'Services', 'Reviews', 'Contact'].map((link) => (
                <li key={link}>
                  <a
                    href={`#${link.toLowerCase()}`}
                    className="text-white/60 hover:text-primary transition-colors"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-primary flex-shrink-0 mt-1" />
                <span className="text-white/60 text-sm">
                  Workshop, Workshop road, near CT Hospital,<br />
                  Barrage Colony, Sukkur, 65200, Pakistan
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-primary flex-shrink-0" />
                <a href="tel:+923093013612" className="text-white/60 hover:text-primary transition-colors text-sm">
                  +92 309 3013612
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Clock size={18} className="text-primary flex-shrink-0" />
                <span className="text-white/60 text-sm">Open daily until 10:00 PM</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/40 text-sm">
            © {new Date().getFullYear()} Advance Dental Clinic. All rights reserved.
          </p>
          <p className="text-white/40 text-sm flex items-center gap-1">
            Made with <Heart size={14} className="text-red-400 fill-red-400" /> in Sukkur
          </p>
        </div>
      </div>
    </footer>
  );
}
